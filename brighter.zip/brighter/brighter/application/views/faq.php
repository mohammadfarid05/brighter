<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>

<title>The Free Platinum-Realtors for Website Template | Home :: w3layouts</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="<?php echo base_url("assets/css/style.css");?>" rel="stylesheet" type="text/css"  media="all" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
<script src="<?php echo base_url("assets/js/jquery.blueberry.js");?>"></script>
		<script>
		$(window).load(function() {
			$('.blueberry').blueberry();
		});
		</script>
</head>
<body>
		<!--  start-wrap -->
		<div class="wrap">
			<!--  start-header -->
			<div class="header">
				<!--  start-logo -->
				<div class="logo">
					<a href="index.php"><marquee direction="right" width="960"><img src="<?php echo base_url("assets/image/briterlogo.png");?>" title="logo"/></marquee> </a>
				</div>
				<!--  end-logo -->
				<!--  start-search-info -->
				
				<div class="clear"> </div>
				<div class="info">
					<p>Website creater in by Mohan kumar – <span>(+91) 9911681545</span></p>
				</div>
				<div class="clear"> </div>
					<div style="margin-bottom:20px;" class="menu-main">
						
						<div class="menu">
							<ul>
					    		<li><a href="#">Home</a></li>
					            <li class="current"><a href="<?php echo base_url()?>index.php/home/about">About</a></li>
					            <li><a href="<?php echo base_url() ?>index.php/home/build">Building</a>
					            	<ul>
					                	<li><a href="#">Building1</a></li>
					                    <li><a href="#">Building2</a></li>
					                    <li><a href="#">Building3</a></li>
					                    <li><a href="#">Building4</a></li>
					                    <div class="clear"> </div>
					                </ul>
					            </li>
					            <li><a href="#">selling</a></li>
					            <li><a href="#">Moving</a></li>
					            <li><a href="<?php echo base_url()?>index.php/home/contact">Contact</a></li>
					            <div class="clear"> </div>
					        </ul>
					        <div class="clear"> </div>
						</div>
						
					</div>
						<!--  end-header -->
						<!--  Img-Slider -->
						<div class="clear"> </div>
				<div class="slider">
					<div class="blueberry">
				      <ul class="slides">
                      
				        
				        <div class="clear"> </div>
				       </ul>
				    </div>
					<div class="clear"> </div>
				<!--  End-of image slider -->
				<div class="content">
					<div class="side-bar">
						<h4>Find Your Property</h4>
						<div class="side-bar-from">
							<p>Price per month:</p>
							<input type="text">
							<p>To:</p>
							<input type="text">
							<p>Location:</p>
							<input type="text">
							<p>Min bedrooms:</p>
							<input type="text">
							<p>Property type:</p>
							<input type="text">
							<p>Availability:</p>
							<input type="text">
							<p>Furnished:</p>
							<input type="text">
							<input type="submit" value="search">
							<input type="reset"  value="Reset">
						</div>
					</div>
				</div>
				<div class="gallery">
					<div class="about">
						<h4>Please Click link to asking question</h4>
						<ul>
				<li><a href="#">Is this property is legal</a></li>
               
				<li><a href="#">To provide the plot and flat at lowest price</a></li>
				<li><a href="#">Provide the job at any profile</a></li>
                <li><a href="#">How to get loan for the plot and can your side is arrengement loan</a></li>
                
               
			</ul>
			
				<div class="clear"> </div>
					
				</div>
	</div>
	<div class="clear"> </div>
	<div class="hr">
    </div>
	<div class="footer"> 
		<div class="footer-grid">
			<h4>Company</h4>
			<ul>
				<li><a href="<?php echo base_url()?>index.php/home/about">About</a></li>
				<li><a href="<?php echo base_url() ?>index.php/home/provider">Services</a></li>

				<li><a href="#">Presentation</a></li>
				<li><a href="#">Clients</a></li>
			</ul>
		</div>
		<div class="footer-grid">
			<h4>Properties</h4>
			<ul>
				<li><a href="#">Commercial</a></li>
				<li><a href="#">Residential</a></li>
				<li><a href="#">Presentation</a></li>
				<li><a href="#">Luxury</a></li>
			</ul>
		</div>
		<div class="footer-grid">
			<h4>FAQs</h4>
			<ul>
				<li><a href="#">FAQs</a></li>
				<li><a href="#">Support</a></li>
			</ul>
		</div>
		<div class="footer-grid">
			<h4>Properties</h4>
			<ul>
				<li><a href="#">Sign up	</a></li>
				<li><a href="#">Forums</a></li>
				<li><a href="#">Presentation</a></li>
				<li><a href="#">Promotions</a></li>
			</ul>
		</div>
		<div class="clear"> </div>
	</div>
	<div class="copy-right">
			<p><a href="http://sunrise.com/">mohan@</a> © 2016 Privacy Policy </p>
		</div>
	<div class="clear"> </div>
</div>
</body>
</html>

