<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sign Up Page</title>
</head>

<body bgcolor="yellow">
<div id="container">
<?php echo form_open('');?>
<h1 align="center">Please Fillup the detail below how to Sign Up </h1>
<table align="center">
<tr>
<td><?php echo form_label('User Name '); ?></td>
<td><?php echo form_input(array('id' => 'username', 'name' => 'username')); ?></td>
<tr>
<td><?php echo form_label('Password '); ?></td>
<td><?php echo form_password(array('id' => 'password', 'name' => 'password')); ?><br/></td>
</tr>
<tr>
<td><?php echo form_label('email '); ?></td>
<td><?php echo form_input(array('id' => 'email', 'name' => 'email')); ?><br/></td>
</tr>

<tr><td></td>
<td><?php echo form_submit(array('id' => 'submit',"name"=>"submit", 'value' => 'Submit')); ?><br/></td>



<?php echo form_close(); ?>
</tr>
</table>
</div>
</body>
</html>
