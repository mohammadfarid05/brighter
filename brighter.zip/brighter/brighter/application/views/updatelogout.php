<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body bgcolor="pink">
<marquee><h1>Welcome to the main page </h1></marquee>
<h1 align="center"><button autofocus ><a href="<?php echo base_url() ?>index.php/updateloginupcon/logout">Click to logout page </a></button></h1>
<h1 align="center"><button autofocus ><a href="<?php echo base_url() ?>index.php/logincon">Click to admin page </a></button></h1>
<h1 align="center"><button autofocus ><a href="<?php echo base_url() ?>index.php/againloginform/"> click  to  Registration  </a></button></h1>


</body>
</html>






