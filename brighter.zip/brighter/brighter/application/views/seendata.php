<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body bgcolor="orange">
<marquee><h1>Welcome to main Admin page</h1></marquee>
<h1 align="center"><button autofocus ><a href="<?php echo base_url() ?>index.php/againloginform/showdata">To Click see the registration data </a></button></h1>
<h1 align="center"><button autofocus ><a href="<?php echo base_url() ?>index.php/updatesignupcon/loginshowdata">To  Click see the login/signup data </a></button></h1>
<h1 align="center"><button autofocus ><a href="<?php echo base_url() ?>index.php/logincon/logout">To Admin plz click here to logout </a>

</body>
</html>
