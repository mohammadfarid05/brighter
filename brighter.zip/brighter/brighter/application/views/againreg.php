<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8">
<title>JavaScript Form Validation using a sample registration form</title>
<meta name="keywords" content="example, JavaScript Form Validation, Sample registration form" />
<meta name="description" content="This document is an example of JavaScript Form Validation using a sample registration form. " />
<link href="<?php echo base_url("assets/css/reg.css");?>" rel="stylesheet" />
<script type='text/javascript' src="<?php echo base_url("assets/js/againreg.js");?>"></script>
</head>
<body onLoad="document.registration.userid.focus();">
<h1><marquee>Welcome  To  Registration  Page</marquee></h1>
<br/>
<form name='registration' onSubmit="return formValidation();" method="post">
<ul>
<li><label for="userid">User id:</label></li>
<li><input type="text" name="userid" size="12" placeholder="userid 5 to 12 " /></li>
<li><label for="passid">Password:</label></li>
<li><input type="password" name="passid" size="12" placeholder="userid 7 to 12 " /></li>
<li><label for="username">Name:</label></li>
<li><input type="text" name="username" size="50" placeholder="please input user name"  /></li>
<li><label for="address">Address:</label></li>
<li><input type="text" name="address" size="50"  placeholder="please input address"/></li>
<li><label for="country">Country:</label></li>
<li><select name="country">
<option selected="" value="Default">(Please select a country)</option>
<option value="Australia">Australia</option>
<option value="Canada">Canada</option>
<option value="India">India</option>
<option value="Russia">Russia</option>
<option value="USA">USA</option>
</select></li>
<li><label for="zip">ZIP Code:</label></li>
<li><input type="text" name="zip" size="20" placeholder="input zip code" /></li>
<li><label for="email">Email:</label></li>
<li><input type="text" name="email" size="50"  placeholder="input emil"/></li>
<li><label id="gender">Sex:</label></li>
<li><input type="radio" name="gender" value="Male" /><span>Male</span></li>
<li><input type="radio" name="gender" value="Female" /><span>Female</span></li>
<li><label>Language:</label></li>
<li><input type="checkbox" name="eng" value="en" checked /><span>English</span></li>
<li><input type="checkbox" name="noneng" value="noen" /><span>Non English</span></li>
<li><label for="desc">About:</label></li>
<li><textarea name="description" id="description" placeholder="Please write the discription about your in word and  maximum 100 words" ></textarea></li>
<li><input type="submit" name="submit" value="Submit" /></li>
</ul>
</form>
</body>
</html>

