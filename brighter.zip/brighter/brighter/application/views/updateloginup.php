<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body bgcolor="sky blue">
<?php echo form_open('updateloginupcon/admin_login');?>
<marquee><h1>Welcome to login  page </h1></marquee>

<table align="center">
<tr>
<td>
<label for="username">Username</label></td>
<td>
<input type="text" name="username" size="20" placeholder="username",<?php echo form_error('username');?>
</td></tr>
<tr>
<td>

<label for="password">Password</label>
</td>
<td>
<input type="password" name="password" size="20" placeholder="password",<?php echo form_error('password');?>
</td></tr>
<tr><td>
<input type="submit" name="submit" size="20"  value="Login" /></td>
<td>
<input type="reset" name="reset" size="20"  value="Reset" />
</td></tr></table>

</body>
</html>
