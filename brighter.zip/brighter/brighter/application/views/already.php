<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8">
<title>Go for Login page</title>
<head

</head>
<body bgcolor="yellow">





<marquee><h1>You are alredy a register user  please click below link to go the login page</h1></marquee>
 <h1 align="center"><button autofocus ><a href="<?php echo base_url() ?>index.php/updateloginupcon/admin_login">Click here for login</a></button></h1>

</body>
</html>
