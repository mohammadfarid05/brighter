<!DOCTYPE html> 
<html lang = "en">
 
   <head> 
      <meta charset = "utf-8"> 
      <title>Students Example</title> 
   </head>
	
   <body bgcolor="#FF0000"> 
      
		
      <table border = "1"> 
         <?php 
            $i = 1; 
            echo "<tr>"; 
            echo "<td>Sr#</td>"; 
            echo "<td>User Id.</td>"; 
            echo "<td>Password</td>"; 
            echo "<td>Name</td>"; 
            echo "<td>Address</td>"; 
            echo "<td>Country</td>";
            echo "<td>zip code</td>";
            echo "<td>Email</td>";
            echo "<td>Sex</td>";
            echo "<td>Language</td>";
            echo "<td>Language</td>";
            echo "<td>About</td>";
            echo "<tr>"; 
				
            foreach($records as $r) { 
               echo "<tr>"; 
               echo "<td>".$i++."</td>"; 
               echo "<td>".$r->userid."</td>"; 
               echo "<td>".$r->passid."</td>";
               echo "<td>".$r->username."</td>";
               echo "<td>".$r->address."</td>"; 
               echo "<td>".$r->country."</td>";
               echo "<td>".$r->zip."</td>";
               echo "<td>".$r->email."</td>";
               echo "<td>".$r->gender."</td>";
               echo "<td>".$r->eng."</td>";
               echo "<td>".$r->noneng."</td>";
               echo "<td>".$r->description."</td>";
               
               echo "<tr>"; 
            } 
         ?>
      </table> 
		
   </body>
	
</html>