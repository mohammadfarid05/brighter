<?php
class Loginmodelcon extends CI_Model{

public function login_valid($username,$password)
{
//$this->load->database();
$q=$this->db->where(['username'=>$username,'password'=>$password])
         ->get('logincon');
         
         if($q->num_rows())
         {
		 
		 
		 return $q->row()->id;
//return true;
}
else
{
return false;
}


}

}