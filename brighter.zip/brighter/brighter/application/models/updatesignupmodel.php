<?php
class Updatesignupmodel extends CI_Model{
function __construct() {
parent::__construct();
}
function contact_insert($data){
$this->db->insert('contact', $data);
}


function sign_insert($data){
$this->db->insert('signup', $data);
}


function valid_insert($data)
{
$q=$this->db->query("SELECT email FROM signup WHERE email='".$data."'");
return $q->row_array();
}


function login_valid($username,$password)
{
$this->load->database();
$q=$this->db->where(['email'=>$email,'password'=>$password])
         ->get('signup');
         
         if($q->num_rows())
         {
		 
		 
		 return $q->row()->id;
//return true;
}
else
{
return false;
}


}


}
?>






