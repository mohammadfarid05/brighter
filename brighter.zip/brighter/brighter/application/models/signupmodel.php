<?php
class Signupmodel extends CI_Model{
function __construct() {
parent::__construct();
}
function form_insert($data){
$this->db->insert('usersignup', $data);
}


function registration_insert($data)
{
$q=$this->db->query("SELECT username FROM usersignup WHERE username='".$data."'");
return $q->row_array();
}


function login_valid($username,$password)
{
$this->load->database();
$q=$this->db->where(['username'=>$username,'password'=>$password])
         ->get('usersignup');
         
         if($q->num_rows())
         {
		 
		 
		 return $q->row()->id;
//return true;
}
else
{
return false;
}


}


}
?>






