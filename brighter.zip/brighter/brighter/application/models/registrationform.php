<?php
class Registrationform extends CI_Model{
function __construct() {
parent::__construct();
}
function form_insert($data){
$this->db->insert('registrationform',$data);
}
/*function getRegistration(){
$query=$this->db->query('SELECT userid,passid,username,address,country,zip,email,gender,eng,noneng,description FROM registrationform');
foreach($query->result_array() as $row)
{
echo $row['userid'];
echo $row['passid'];
echo $row['username'];
echo $row['address'];
echo $row['country'];
echo $row['zip'];
echo $row['email'];
echo $row['gender'];
echo $row['eng'];
echo $row['noneng'];
echo $row['description'];

}

}*/
}
?>
