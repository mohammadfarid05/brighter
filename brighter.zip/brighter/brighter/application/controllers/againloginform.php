<?php 
   class Againloginform extends CI_Controller 
	   {
      function __construct() 
	  { 
         parent::__construct();
		 $this->load->helper('form');
           $this->load->database();
		   $this->load->library('form_validation');
		   $this->load->helper(array('form','url'));

		$this->load->library('javascript');
		 $this->load->model('registrationform');
		  
		   }
		   function index() { 
         
		 $data=array();
		 if($this->input->post('submit')!='')
		 {
		
		 if($this->input->post('userid')!='')
		 {
		 $data['userid']=$this->input->post('userid');
		 
		}
		 if($this->input->post('passid')!='')
		  {
		 $data['passid']=$this->input->post('passid');
		 
		 }
		  if($this->input->post('username')!='')
		  {
		 $data['username']=$this->input->post('username');
		
		 }
		  if($this->input->post('address')!='')
		  {
		 $data['address']=$this->input->post('address');
		 
		}
		 if($this->input->post('country')!='')
		 {
		 $data['country']=$this->input->post('country');
		 
		 }
		 if($this->input->post('zip')!='')
		 {
		 $data['zip']=$this->input->post('zip');
		 }
		 if($this->input->post('email')!='')
		 {
		 $data['email']=$this->input->post('email');
		 }
		 if($this->input->post('gender')!='')
		 {
		 $data['gender']=$this->input->post('gender');
		 }
		 if($this->input->post('eng')!='')
		 {
		 $data['eng']=$this->input->post('eng');
		 }
		 if($this->input->post('noneng')!='')
		 {
		 $data['noneng']=$this->input->post('noneng');
		 }
		 if($this->input->post('description')!='')
		 {
		 $data['description']=$this->input->post('description');
		//$data['description']=$this->input->post('description');
		 }
		 
         
		//print_r($data);die;
		 if(count($data)>0)
         {
        $query =$this->registrationform->form_insert($data);
		  //echo $this->db->last_query(); this query is print for last query;
          }
		  
		  
		  
        // $query=$this->registrationform->getRegistration();
		$query = $this->db->get("registrationform"); 

         }
         $this->load->view('againreg',$data);
		 
		 /*$data['message']='Data inserted Successfully';
        $query = $this->db->get("registrationform"); 
         $data['records'] = $query->result(); 
		$this->load->view('seedata',$data);
*/		 }
		 function showdata()
		 {
		 $data['message']='Data inserted Successfully';
        $query = $this->db->get("registrationform"); 
         $data['records'] = $query->result(); 
		$this->load->view('seedata',$data);
		 
		 }
		
         }
        ?>

		 




