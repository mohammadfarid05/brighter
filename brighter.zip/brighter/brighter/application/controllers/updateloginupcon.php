
<?php

class Updateloginupcon extends CI_Controller {
public function index()
{
$this->load->helper('form');
$this->load->view('updateloginup');


}
public function admin_login()
{
$this->load->library('form_validation');
$this->form_validation->set_rules('username','Username','required|alpha|trim');
$this->form_validation->set_rules('password','Password','required');

if($this->form_validation->run())
{
$username=$this->input->post('username');
$password=$this->input->post('password');
echo "username: $username and password: $password";
$this->load->model('signupmodel');



$login_id=$this->signupmodel->login_valid($username,$password);
if($login_id)
{
echo "password match";
//$this->load->library('session');
$this->session->set_userdata('user_id',$login_id);
//$this->load->view('dashboard');
redirect('updateadmin');


}
else
{
echo "password dont match";


}


}
else 
{
$this->load->view('updateloginup');
}
//$this->load->view('seendata');
 
}
public function logout()
{
$this->session->unset_userdata('user_id',$login_id);
return redirect('updateloginupcon');


}
public function register()
{
$this->load->view('registrationsuccessfully');
	
	}
	
	public function user()
	{
		
	$this->load->view('already');	
    }

}


?>