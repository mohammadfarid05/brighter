<?php
class Contact extends CI_Controller {
function __construct() {
parent::__construct();
$this->load->helper('form');
 $this->load->database();
}
function index()
{

$this->load->model('updatesignupmodel');
//$this->load->model('insert_model');
$this->load->helper(array('form','url'));
$data=array();
if($this->input->post('submit')!='')
{

if($this->input->post('name')!='')
{
$data['name']=$this->input->post('name');
}
if($this->input->post('email')!='')
{
$data['email']=$this->input->post('email');
}
if($this->input->post('phone')!='')
{
$data['phone']=$this->input->post('phone');
}
if($this->input->post('message')!='')
{
$data['message']=$this->input->post('message');
}
if(count($data)>0)
{
  $this->updatesignupmodel->contact_insert($data);
 
}
//redirect("main_controller");
$data['message']='Data inserted Successfully';
 
}
	//$data['show']=$this->validate_model->getValidationlogin();
	//print_r($data['show']);die;
	$this->load->view('contact',$data);
	//$this->load->view('valretrive',$data);
}
}
?>


 