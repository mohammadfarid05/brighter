<?php
class Updatesignupcon extends CI_Controller {
function __construct() {
parent::__construct();
 $this->load->helper('form');
 $this->load->database();
}



function index()
{
$this->load->helper(array('form','url'));


$data=array();
if($this->input->post('submit')!='')
{

if($this->input->post('username')!='')
{
$data['username']=$this->input->post('username');
}
if($this->input->post('password')!='')
{
$data['password']=$this->input->post('password');
}
if($this->input->post('email')!='')
{
$data['email']=$this->input->post('email');
}
$this->load->model('signupmodel');

 //$data['message']='Data inserted Successfully';
 
 
 
 


 
 
 $result = $this->signupmodel->registration_insert($this->input->post('username'));
 //print_r($result);die;
if (count($result)==0) 
{
	if(count($data)>0)
	{
	  $this->signupmodel->form_insert($data);
	}
	//$data['message_display'] = 'Registration Successfully !';
 //echo '<h1>registration successfully</h1>';
 //redirect('updatesignupcon');
 //$this->load->view('registrationsuccessfully');
 redirect('updateloginupcon/register');

} 

else {
//$data['message_display'] = 'Username already exist!';
//echo '<h1>Username already exist!</h1>';
redirect('updateloginupcon/user');

}
 
}


$this->load->view('updatesignup',$data);

}
function loginshowdata()
		 {
		 $data['message']='Data inserted Successfully';
        $query = $this->db->get("usersignup"); 
         $data['records'] = $query->result(); 
		$this->load->view('logindatasee',$data);
	}	




}
?>