<?php
class Updateadmin extends CI_Controller
{
public function index()
{
if(!$this->session->userdata('user_id'))
return redirect('updateloginupcon');

$this->load->helper('form');

$this->load->view('updatelogout');

}

public function _construct()
{
parent::_construct();
if(!$this->session->userdata('user_id'))
return redirect('updateloginupcon');

}

}
?>